function setup() {
    createCanvas(900, 800, WEBGL);

}

function draw() {
    background(125);
    angleMode(DEGREES);
}
