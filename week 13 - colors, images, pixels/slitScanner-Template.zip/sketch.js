var video;

function setup() {
    createCanvas(640 * 2, 480);
    pixelDensity(1);
    video = createCapture(VIDEO);
    video.hide();
}

function draw() {
    image(video, 0, 0);

    // STEP 1 - write your cocde below


    push();
    stroke(255, 0, 0);
    line(video.width / 2, 0, video.width / 2, video.height);
    pop();

    // STEP 2 - write your code below


}
